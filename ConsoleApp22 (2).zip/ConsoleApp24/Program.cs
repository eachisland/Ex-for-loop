﻿using System.Collections.Generic;

namespace ConsoleApp19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n = double.Parse(Console.ReadLine());
            double salary = double.Parse(Console.ReadLine());
            int instagram = 100;
            int facebook = 150;
            int reddit = 50;

            for (int i = 0; i < n; i++)
            {
                string tab = Console.ReadLine();
                if (tab == "Instagram")
                {
                    salary -= instagram;
                }
                else if (tab == "Facebook")
                {
                    salary -= facebook;
                }
                else if (tab == "Reddit")
                {
                    salary -= reddit;
                }

            }
            if (salary <= 0)
            {
                Console.WriteLine("You have lost your salary.");
            }
            else
            {
                Console.WriteLine(salary);
            }
        }
    }
}